

#!/bin/bash

loop_status=0

while true; do    
    loop_status=1
    if [ loop_status=1 ]; then
        break
    fi
done
